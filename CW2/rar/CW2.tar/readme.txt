	[2 marks]	Code correctly reads in the vertices, normals & texture coordinates.       Done	
	[2 marks]	Surface renders at all.							   Done
	[2 marks]	Surface is correctly Phong shaded (with textures turned off)	           Not done  
	[2 marks]	Surface is textured correctly (with lighting modulation)		   Done withouth the light
	[1 mark]	Application implements translation and arcball rotation			   Not done
	[1 mark]	Stages of rendering can be (de-)activated while app is running	 	   Not done 



The stb_image.h is for reading texture from ppm file. I included both compiled and not compiled shaders. Change the MODEL_PATH in source.cpp to path of the model 

